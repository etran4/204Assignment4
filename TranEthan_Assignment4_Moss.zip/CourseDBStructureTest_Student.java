import static org.junit.Assert.*;

import java.io.IOException;
import java.util.ArrayList;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * This is the test file for the CourseDBManager which is implemented from the
 * CourseDBManagerInterface
 * 
 */
public class CourseDBStructureTest_Student {
	CourseDBStructure cds, testStructure;

	@Before
	public void setUp() throws Exception {
		cds = new CourseDBStructure(20);
		testStructure = new CourseDBStructure("Testing", 20);
	}

	@After
	public void tearDown() throws Exception {
		cds = testStructure = null;
	}

	/**
	 * Test the tableSize for CourseDBStructures constructed with both constructors
	 */
	@Test
	public void testGetTableSize() {
		assertEquals(19, cds.getTableSize());
		assertEquals(20, testStructure.getTableSize());
	}

	@Test
	public void testHashTable() {

		 
		CourseDBElement cde1 = new CourseDBElement("Psych101", 45678, 2, "SA140", "Nothing");
		
		cds.add(cde1);  
		cds.add(cde1);  
	 
		ArrayList<String> courseList = cds.showAll(); 
		assertTrue(courseList.size()==1);  
		
		
		CourseDBElement cde2 = new CourseDBElement("Psych140", 7890, 2, "SA140", "Nothing");
	 
 		try {
			assertEquals(45678, cds.get(cde1.getCRN()).getCRN());  
			cds.get(cde2.getCRN()).getCRN(); 
		} catch (IOException e) {

			assertTrue("threw Exception successfuly for the course not found", true);
		}
		
 		cds.add(cde2);
 		courseList = cds.showAll(); 
		assertTrue(courseList.size()==2);  
		
		try {
			assertEquals(7890, cds.get(cde2.getCRN()).getCRN());
		} catch (IOException e) {
			 
			fail("Should not throw exception");
		}  
		CourseDBElement cde1Update = new CourseDBElement("Psych101-updated", 45678, 2, "SA140", "updated");
		cds.add(cde1Update);  
 		courseList = cds.showAll(); 
		assertTrue(courseList.size()==2);  
		
		try {
			assertEquals(45678, cds.get(cde1Update.getCRN()).getCRN());
			assertEquals("Psych101-updated", cds.get(cde1Update.getCRN()).getID());
		} catch (IOException e) {
			 
			fail("Should not throw exception");
		}  
		testStructure.add(cde1); 
		courseList = testStructure.showAll(); 
		assertTrue(courseList.size()==1); 
	}
}
