/**
 * Database class
 * @author Ethan Tran
*/
public class CourseDBElement implements Comparable<CourseDBElement>{
    private String id;
    private int crn;
    private int credits;
    private String roomNum;
    private String instructor;

    public CourseDBElement() {
    }
    
    /**
     * @param id course id
	 * @param crn course crn
	 * @param credits number of credits
	 * @param roomNum course room number
	 * @param instructor name of the instructor
     */
    public CourseDBElement(String id, int crn, int credits, String roomNum, String instructor) {
        this.id = id;
        this.crn = crn;
        this.credits = credits;
        this.roomNum = roomNum;
        this.instructor = instructor;
    }

    /**
     * Gets course id
     * @return course id
     */
    public String getID() {
        return id;
    }

    /**
     * Gets course crn
     * @return course crn
     */
    public int getCRN() {
        return crn;
    }

    /**
     * Gets course credits
     * @return course credits
     */
    public int getCredits() {
        return credits;
    }

    /**
     * Get course room number
     * @return course room number
     */
    public String getRoomNum() {
        return roomNum;
    }

    /**
     * Get course instructor
     * @return course instructor
     */
    public String getInstructor() {
        return instructor;
    }
    
    /**
     * Sets course id
     * @param id: course id
     */
    public void setID(String id) {
        this.id = id;
    }

    /**
     * Sets course crn
     * @param crn: course crn
     */
    public void setCRN(int crn) {
        this.crn = crn;
    }

    /**
     * Sets course credits
     * @param credits: course credits
     */
    public void setCredits(int credits) {
        this.credits = credits;
    }

    /**
     * Sets course room number
     * @param roomNum: course roomNum
     */
    public void setRoomNum(String roomNum) {
        this.roomNum = roomNum;
    }

    /**
     * Sets course instructor
     * @param instructor: course instructor
     */
    public void setInstructor(String instructor) {
        this.instructor = instructor;
    }
    
    public int hashCode() {
		return crn;		
	}

    public String toString() {
		return "\nCourse:"+id+" CRN:"+crn+" Credits:"+credits+" Instructor:"+instructor+" Room:"+roomNum;
	}

    public int compareTo(CourseDBElement element) {
        if (crn == element.crn) {
            return 0;
        } else if(crn > element.crn) {
            return 1;
        }
        return -1;
    }
}