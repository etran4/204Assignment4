/**
* LinkedList implementation
* @Author Ethan Tran
*/
public class LinkedList<T extends Comparable<T>> {
    private int size;
    private Node head;

    public LinkedList() {
        this.size = 0;
    }

    /**
     * Checks if list contains a specific element
     * @param entry: element that is being checked to see if list contains it
     * @return true or false if entry is in the array
     */
    public boolean contains(T entry) {
        Node i = head;
        while (i != null) {
            if (i.getData().compareTo(entry) == 0) {
                return true;
            }
            i = i.getNext();
        }
        return false;
    }
    
    /**
     * Adds element to the list
     * @param entry: element being added to the list
     */
    public void add(T entry) {
        head = new Node(entry, head);
        size++;
    }

    public boolean remove(T removing) {
        if (!isEmpty()) {
            Node i = head;
            Node prev = null;
            
            while (i != null) {
                if (i.getData().compareTo(removing) == 0) {
                    if (prev != null) {
                    	prev.next = i.getNext();
                    }
                    size--;
                    return true;
                }
                prev = i;
                i = i.getNext();
            }
            return false;
        }
        return false;
    }

    /**
     * Get size of the list
     * @return list size
     */
    public int getCurrentSize() {
        return size;
    }
    
    /**
     * Checks if list empty
     * @return empty list
     */
    public boolean isEmpty() {
        return size == 0;
    }

    private class Node {
        private Node next;
        private T data;
        public Node(T data, Node next) {
            this.data = data;
            this.next = next;
        }
        public void setData(T data) {
            this.data = data;
        }
        public T getData() {
            return data;
        }
        public Node getNext() {
            return this.next;
        }
    }
    
    /**
     * Get array containing elements of the list
     * @return array of elements of the list
     */
    @SuppressWarnings("unchecked")
    public T[] toArray() {
        T[] array = (T []) new Comparable[size];
        Node i = head;
        for (int x = 0; x < size; x++) {
            array[x] = i.getData();
            i = i.getNext();
        }
        return array;
    }
}