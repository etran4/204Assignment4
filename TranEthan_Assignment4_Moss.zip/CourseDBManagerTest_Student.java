import static org.junit.Assert.*;

import java.io.File;
import java.io.PrintWriter;
import java.util.ArrayList;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * This is the test file for the CourseDBManager
 * which is implemented from the CourseDBManagerInterface
 * 
 */
public class CourseDBManagerTest_Student {
	private CourseDBManagerInterface dataMgr = new CourseDBManager();

	/**
	 * Create an instance of CourseDBManager
	 * @throws Exception
	 */
	@Before
	public void setUp() throws Exception {
		dataMgr = new CourseDBManager();
	}

	/**
	 * Set dataMgr reference to null
	 * @throws Exception
	 */
	@After
	public void tearDown() throws Exception {
		dataMgr = null;
	}

	/**
	 * Test for the add method
	 */
	@Test
	public void testAddToDB() {
		try {
			dataMgr.add("DSTR140",10001,2,"PE120","Andrew Barne");
		}
		catch(Exception e) {
			fail("This should not have caused an Exception");
		}
	}
	
	/**
	 * Test for the showAll method
	 */
	@Test
	public void testShowAll() {
		dataMgr.add("DSTR140",10001,2,"PE120","Andrew Barne");
		dataMgr.add("DSTR140",10002,2,"PE120","Jin Sang");
		dataMgr.add("DSTR200",10003,2,"PE120","Bink Boing");
		ArrayList<String> list = dataMgr.showAll();
		assertEquals(list.get(0),"\nCourse:DSTR200 CRN:10003 Credits:2 Instructor:Bink Boing Room:PE120");
	 	assertEquals(list.get(1),"\nCourse:DSTR140 CRN:10002 Credits:2 Instructor:Jin Sang Room:PE120");
		assertEquals(list.get(2),"\nCourse:DSTR140 CRN:10001 Credits:2 Instructor:Andrew Barne Room:PE120");
	}
	
	/**
	 * Test for the read method
	 */
	@Test
	public void testRead() {
		try {
			File inputFile = new File("Test1.txt");
			PrintWriter inFile = new PrintWriter(inputFile);
			inFile.println("DSTR140 10001 2 PE120 Andrew Barne");
			inFile.print("DSTR200 10002 2 PE120 Jin Sang");
			
			inFile.close();
			dataMgr.readFile(inputFile);
			assertEquals("DSTR140",dataMgr.get(10001).getID());
			assertEquals("DSTR200",dataMgr.get(10002).getID());
			assertEquals("PE120",dataMgr.get(10002).getRoomNum());
		} catch (Exception e) {
			fail("Should not have thrown an exception");
		}
	}
}