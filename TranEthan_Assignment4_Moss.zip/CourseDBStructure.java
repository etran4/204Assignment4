/**
* Course database structure class
* @Author Ethan Tran
*/

import java.io.IOException;
import java.util.ArrayList;

public class CourseDBStructure {
    static double LOADING_FACTOR = 1.5;
    private LinkedList<CourseDBElement>[] hashTable;
    private int size;

    /**
     * Checks a number to see if it is a prime
     * @param y is a possible prime number
     * @return true or false depending if y is a prime number or not
     */
    public boolean isPrime(int y) {
        for (double x = 2; x < y; x++) {
            if (y / x % 1 == 0) {
                return false;
            }
        }
        return true;
    }

    /**
     * @param testing: string for testing
     * @param size: size of hashTable
     */
    public CourseDBStructure(String testing, int size) {
        this.size = size;
        hashTable = new LinkedList[size];
    }
    
    /**
     * @param size: number of words
     */
    public CourseDBStructure(int size) {
        size = (int)(size / LOADING_FACTOR);
        do {
            size++;
        } while (!((((size - 3) / 4.0) % 1 == 0) && isPrime(size)));
        this.size = size;
        hashTable = new LinkedList[size];
    }

    /**
	* Adds a CourseDBElement object to the CourseDBStructure using the hashcode
	* of the CourseDatabaseElemen object's crn value.
	* If the CourseDatabaseElement already exists, exit quietly
	*
	* @param element the CourseDBElement to be added to CourseDBStructure
	*/
	public void add(CourseDBElement element) {
        int crn = element.getCRN();
        int index = crn % size; 
	LinkedList<CourseDBElement> bucket = hashTable[index];
        if (bucket == null) {
            bucket = new LinkedList<CourseDBElement>();
            hashTable[index] = bucket;
        }
        
        try {
            if (get(crn) != null) {
            	bucket.remove(element);
            }
            bucket.add(element);
        } catch(Exception e) {
        }
	}

	/**
	 * Find a courseDatabaseElement based on the key (crn) of the
	 * courseDatabaseElement If the CourseDatabaseElement is found return it If not,
	 * throw an IOException
	 *
	 * @param crn crn (key) whose associated courseDatabaseElement is to be returned
	 * @return a CourseDBElement whose crn is mapped to the key
	 * @throws IOException if key is not found
	 */
	public CourseDBElement get(int crn) throws IOException {
        int index = crn % size;
        LinkedList<CourseDBElement> bucket = hashTable[index];
        if (bucket == null) {
            throw new IOException();
        }

        for (Object element: bucket.toArray()) {
            CourseDBElement course = (CourseDBElement) element;
            if (course.getCRN() == crn) {
                return course;
            }
        }
        return null;
	}

	/**
	 * @return an array list of string representation of each course in
	 * the data structure separated by a new line.
	 * Refer to the following example:
	 * Course:CMSC500 CRN:39999 Credits:4 Instructor:Nobody InParticular Room:SC100
	 * Course:CMSC600 CRN:4000 Credits:4 Instructor:Somebody Room:SC200
	 */
	public ArrayList<String> showAll() {
	    ArrayList<String> array = new ArrayList<>();

	    for (LinkedList<CourseDBElement> bucket: hashTable) {
	        if (bucket != null) {
                for (Object element: bucket.toArray()) {
                    array.add(element.toString());
                }
            }
        }
	    return array;
	}

	/**
	* Returns the size of the ConcordanceDataStructure (number of indexes in the array)
	*/
	public int getTableSize() {
	    return size;
	}
}